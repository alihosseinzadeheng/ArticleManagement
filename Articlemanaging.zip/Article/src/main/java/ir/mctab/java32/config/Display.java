package ir.mctab.java32.config;

public class Display {

    public static void entryOrders(){
        System.out.println(" ----------\n" +
                "* register\n" +
                "* login\n" +
                "* show articles\n" +
                "* exit\n" +
                "----------\n");
    }
    public static void ArticleOrders(){
        System.out.println(" ----------\n" +
                "* show my articles\n" +
                "* create an article\n" +
                "* edit an article\n" +
                "* publish an article\n" +
                "* search an article\n" +
                "* change password\n" +
                "* logout\n" +
                "* exit\n" +
                "----------\n");
    }

}
